import flask
from twilio import twiml
import os


# Instantiate Flask app.
app = flask.Flask(__name__)


# Accept a POST request from Twilio, and provide TwiML to put caller in a
# queue.
@app.route('/caller', methods=['GET', 'POST'])
def caller():
    response = twiml.Response()
    response.enqueue("Queue Demo")
    return str(response)


# Accept a POST request from Twilio, and provide TwiML to connect agent
# with first caller in the Queue.
@app.route('/agent', methods=['GET', 'POST'])
def agent():
    response = twiml.Response()
    with response.dial() as dial:
        dial.queue("Queue Demo")
    return str(response)


if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.debug = True
    app.run(host='0.0.0.0', port=port)
