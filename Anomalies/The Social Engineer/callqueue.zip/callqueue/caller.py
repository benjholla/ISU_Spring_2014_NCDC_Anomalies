import flask
from twilio import twiml
import os


# Instantiate Flask app.
app = flask.Flask(__name__)


# Accept a POST request from Twilio, and provide TwiML to put caller
# in a queue.
@app.route('/caller', methods=['GET', 'POST'])
def caller():
    response = twiml.Response()
    # Use Enqueue verb to place caller in a Queue
    response.enqueue("Queue Demo")
    return str(response)


# Boiler plate to make the app run when executing: python app.py
if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.debug = True
    app.run(host='0.0.0.0', port=port)
